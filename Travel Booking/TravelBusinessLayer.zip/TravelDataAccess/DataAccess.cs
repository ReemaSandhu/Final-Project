﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TravelDataAccess.Interface;
using TravelEntities.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using TravelEntities.CustomEntities;
using System.Data;

namespace TravelDataAccess
{
    public class DataAccess :IDataAccess
    {
        private readonly TravelDbContext _travelDbContext;
        public DataAccess(TravelDbContext travelDbContext)
        {
            _travelDbContext = travelDbContext;
        }

        public int AddGuest(Guest guest)
        {
            _travelDbContext.Guest.Add(guest);
            return _travelDbContext.SaveChanges();
        }

        public List<City> GetCities()
        {
            return _travelDbContext.City.ToList(); 
        }
        //EXEC [dbo].[GetBooking] '2021-04-18 17:18:11.463','2021-04-21 17:18:11.463',1
        //public List<SearchHotels> GetHotelList(DateTime CheckIn, DateTime CheckOut, long CityId)
        //{
        //    List<DisplayHotels> searchhotel;
        //    //try
        //    //{
        //        //searchhotel = (_travelDbContext.SearchHotels.FromSqlRaw("[dbo].[GetBooking] @Checkin,@Checkout,@City",
        //        //    new SqlParameter("@Checkin", Convert.ToDateTime(CheckIn)),
        //        //     new SqlParameter("@Checkout", Convert.ToDateTime(CheckOut)),
        //        //     new SqlParameter("@City", Convert.ToInt64(CityId)))).ToList();
        //        searchhotel= (_travelDbContext.DisplayHotels.FromSqlRaw("EXEC [dbo].[GetBooking]'"+CheckIn+"','"+ CheckOut+"',"+ CityId)).ToList();
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    searchhotel = null;
        //    //}
        //    return null;
        //}
        public CombinedModel GetHotelList(DateTime CheckIn, DateTime CheckOut, long CityId)
        {
            CombinedModel comb = new CombinedModel();

            
            comb.DisplayHotels = (_travelDbContext.DisplayHotels.FromSqlRaw("EXEC [dbo].[GetBooking]'" + CheckIn + "','" + CheckOut + "'," + CityId)).ToList();
            
            return comb;
        }

        //public List<Hotel> GetHotels()
        //{
        //    List<Hotel> hotels = _travelDbContext.Hotel.FromSqlRaw("[dbo].[GetBooking]").ToList();
        //    return hotels;
        //}

        //public long InsertValues(SearchHotels search)
        //{
        //    long result = 0;
        //    SqlParameter resultParameter = new SqlParameter();
        //    try
        //    {

        //        resultParameter.Direction = ParameterDirection.Output;
        //        resultParameter.SqlDbType = SqlDbType.BigInt;
        //        _travelDbContext.Database.ExecuteSqlRaw("[dbo].[GetBooking],@Checkin,@Checkout,@City",
        //             new SqlParameter("@Checkin", search.CheckIn),
        //             new SqlParameter("@Checkout", search.CheckOut),
        //             new SqlParameter("@City", search.CityId),
        //             resultParameter
        //             );
        //        if (Convert.ToInt32(resultParameter.Value) > 0)
        //            result = Convert.ToInt32(resultParameter.Value);
        //    }
        //    catch (Exception)
        //    {
        //        result = 0;
        //    }
        //    return result;
        //}
    }
}
