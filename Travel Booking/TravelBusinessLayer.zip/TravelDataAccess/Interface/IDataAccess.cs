﻿using System;
using System.Collections.Generic;
using System.Text;
using TravelEntities.CustomEntities;
using TravelEntities.Entities;

namespace TravelDataAccess.Interface
{
    public interface IDataAccess
    {
         List<City> GetCities();

        //List<Hotel> GetHotels();

        //long InsertValues(SearchHotels search);
        CombinedModel GetHotelList(DateTime CheckIn,DateTime CheckOut,long CityId);
        int AddGuest(Guest guest);
    }
}
