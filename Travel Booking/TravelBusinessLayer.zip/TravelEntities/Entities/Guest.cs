﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace TravelEntities.Entities
{
    public partial class Guest
    {
        public Guest()
        {
            Booking = new HashSet<Booking>();
        }

        public long GuestId { get; set; }
        public string GuestFirstName { get; set; }
        public string GuestLastName { get; set; }
        public string Email { get; set; }
        public long MobileNumber { get; set; }

        public virtual ICollection<Booking> Booking { get; set; }
    }
}
