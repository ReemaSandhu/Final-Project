﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace TravelEntities.Entities
{
    public partial class City
    {
        public City()
        {
            Booking = new HashSet<Booking>();
            Hotel = new HashSet<Hotel>();
        }

        public long CityId { get; set; }
        public string CityName { get; set; }

        public virtual ICollection<Booking> Booking { get; set; }
        public virtual ICollection<Hotel> Hotel { get; set; }
    }
}
