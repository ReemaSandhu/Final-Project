﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace TravelEntities.Entities
{
    public partial class Hotel
    {
        public Hotel()
        {
            Booking = new HashSet<Booking>();
        }

        public long HotelId { get; set; }
        public string HotelName { get; set; }
        public long CityId { get; set; }
        public string HotelImage { get; set; }

        public virtual City City { get; set; }
        public virtual ICollection<Booking> Booking { get; set; }

        [NotMapped]
        [DisplayName("Upload Image")]
        public IFormFile ImageUploader { get; set; }
    }
}
