﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace TravelEntities.Entities
{
    public partial class Booking
    {
        public long BookingId { get; set; }
        public long HotelId { get; set; }
        public long GuestId { get; set; }
        public DateTime CheckIn { get; set; }
        public DateTime CheckOut { get; set; }
        public long NoOfPeople { get; set; }
        public long CityId { get; set; }

        public virtual City City { get; set; }
        public virtual Guest Guest { get; set; }
        public virtual Hotel Hotel { get; set; }
    }
}
