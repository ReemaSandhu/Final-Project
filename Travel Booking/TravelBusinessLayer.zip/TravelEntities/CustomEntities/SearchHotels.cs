﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TravelEntities.Entities;

namespace TravelEntities.CustomEntities
{
    public class SearchHotels
    {
        [Key]
        public long BookingId { get; set; }
        public DateTime CheckIn { get; set; }
        public DateTime CheckOut { get; set; }
        public long NoOfPeople { get; set; }

        public long CityId { get; set; }



    }
}
