﻿using System;
using System.Collections.Generic;
using System.Text;
using TravelBusinessLayer.Interface;
using TravelDataAccess.Interface;
using TravelEntities.CustomEntities;
using TravelEntities.Entities;

namespace TravelBusinessLayer
{
    public class TravelComponent : ITravelComponent
    {
        private readonly IDataAccess _data;

        public TravelComponent(IDataAccess data)
        {
            _data = data;
        }

        public int AddGuest(Guest guest)
        {
            return _data.AddGuest(guest);
        }

        public List<City> GetCities()
        {
            return _data.GetCities();
        }

        public CombinedModel GetHotelList(DateTime CheckIn, DateTime CheckOut, long CityId)
        {
            return _data.GetHotelList(CheckIn, CheckOut, CityId);
        }

        //public List<Hotel> GetHotels()
        //{
        //    return _data.GetHotels();
        //}

        //public long InsertValues(SearchHotels search)
        //{
        //    return _data.InsertValues(search);
        //}
    }
}
