﻿using System;
using System.Collections.Generic;
using System.Text;
using TravelEntities.CustomEntities;
using TravelEntities.Entities;

namespace TravelBusinessLayer.Interface
{
    public interface ITravelComponent
    {
        List<City> GetCities();
        //List<Hotel> GetHotels();
        //long InsertValues(SearchHotels search);
        CombinedModel GetHotelList(DateTime CheckIn, DateTime CheckOut, long CityId);

        int AddGuest(Guest guest);
    }
}
